const TODO = require("../models/todoModel");

const addtask = async (req, res) => {
  try {
    let { description, deadline } = req.body;

 

    const task = await TODO.create({
      description,
      deadline,
     });

    if (!task) {
      console.log("coudnt add task");
      return;
    }

    return res.redirect('/v1/todo/')
  } catch (err) { 
    console.log(err);
  }
};

const deleteTask = async (req, res) => {
  const { id } = req.params;

  const task = await TODO.findOneAndDelete({ _id: id });

  res.redirect("/v1/todo/")
};

const getAllTask = async (req, res) => {


const {search,sort}=req.query; 

if(sort){


  if(sort==='duedate'){
    const task=await TODO.find({} ).sort({'deadline':1})
    return res.render('home',{
      allTask:task
    })
  }
else{
  const task=await TODO.find({} ).sort({'createdAt':-1})
  return res.render('home',{
    allTask:task
  })
}




}

if(!search){
  const allTask = await TODO.find({});

 return  res.render('home',{

    allTask:allTask
  })
}



const allTask=await TODO.find({status:search})  
return res.render('home',{
  allTask:allTask
})




};



const completeTask=async (req,res)=>{
    try{

        const {id}=req.params;

        const task=await TODO.updateOne({_id:id},{
            $set:{status:"completed"}
        })
        
        
        return res.redirect("/v1/todo")
       
       
    }
catch(err){
    console.log(err)
}
}









module.exports = { addtask, deleteTask, getAllTask,completeTask };
