const mongoose = require("mongoose");


const databaseConnection= async()=>{


try{
    mongoose.set("strictQuery", false);
   await  mongoose.connect("mongodb+srv://gurpreetsingh:Shalu%401999@cluster0.apn6ahn.mongodb.net/?retryWrites=true&w=majority")
console.log("mongoDB Connected")
}



catch(err){
console.log(err)
}
}
module.exports=databaseConnection

