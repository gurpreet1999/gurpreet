
const express=require('express')
const databaseConnection = require('./config/databaseConnection')
const indexRouter = require('./routes')
const path=require('path')
const ejs=require('ejs')

const app=express()

databaseConnection()



// setting up view engine as ejs
app.set('view engine',"ejs")
// //setting path of views folder
app.set('views',path.join(__dirname,'views'))

//  //accesing static files from assets folder
app.use(express.static('assets'))

app.use(express.json())

app.use(express.urlencoded({extended:true}))


//setting index file for all the routes
app.use('/v1/todo',indexRouter)

app.listen(4000,(err)=>{

    if(err){
        console.log(err)
    }
    
        console.log("server is runninng fine ")
    })

    