const express=require('express')
const dbConnection = require('./databaseConfig/databaseConnection.js')

const passport=require("passport")
const passportLocal=require('./middleware/passport-local-strategy.js')
var cookieParser = require('cookie-parser')
const path=require('path')
const expressLayout=require('express-ejs-layouts')
const indexRouter = require('./routes/index.js')
const session=require('express-session')
const MongoStore=require("connect-mongo")
const flash = require("connect-flash");
const customFlash = require("./middleware/flashMiddleware.js");


const app=express()
app.use(cookieParser())
dbConnection()
app.use(express.json())
app.use(express.urlencoded({extended:true}))






app.use(express.static('public'))


//set up view engine

app.use(expressLayout)
// app.set('layout extractStyles', true);
// app.set('layout extractScripts', true);  
app.set('view engine','ejs')
app.set('views',path.join(__dirname,'views'))



//after the view i need to do express-session
app.use(session({
   name:"placement" ,
   secret:"abcde",
   saveUninitialized:false,
   resave:false,
   cookie:{
    maxAge:(1000*60*100)
   },

   store:new MongoStore({
    mongoUrl:"mongodb+srv://gurpreetsingh:Shalu%401999@cluster0.apn6ahn.mongodb.net/?retryWrites=true&w=majority",
    autoRemove: "disabled",
   }),
    function(err) {
      console.log(err || "connect-mongodb setup ok");
    },
})



)






app.use(passport.initialize())
app.use(passport.session())
app.use(passport.setAuthenticatedUser)

app.use(flash());
app.use(customFlash.setFlash);


app.use('/v1',indexRouter)


app.listen(4000,()=>{
    console.log("server is running fine")
})