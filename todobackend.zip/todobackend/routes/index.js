const express = require("express");
const {
  addtask,
  deleteTask,
  getAllTask,
  completeTask,
} = require("../controllers/homeController");

const indexRouter = express.Router();

indexRouter.get("/", getAllTask);
indexRouter.post("/create", addtask);

indexRouter.get("/delete/:id", deleteTask);
indexRouter.get("/complete/:id", completeTask);

module.exports = indexRouter;
