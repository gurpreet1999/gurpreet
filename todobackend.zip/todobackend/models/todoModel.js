const mongoose=require('mongoose')




const todoSchema=new mongoose.Schema({
description:{
    type:String,
    required:true
}
,
deadline:{
    type:String,
    required:true
},
status:{
    type:String,
    enum:["active","completed"],
    default:"active"
}

},{
    timestamps:true
})


todoSchema.pre('save', function (next) {
    const words = this.description.split(' ')
    this.description = words
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ')
    next()
  })





const TODO=mongoose.model('TODO',todoSchema)

module.exports=TODO